package com.example.commerce.service;

import com.example.commerce.domain.Mail;

public interface MailService {
    public void sendEmail(Mail mail);
}
